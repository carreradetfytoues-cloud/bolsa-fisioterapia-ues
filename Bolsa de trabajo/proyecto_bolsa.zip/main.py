from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import sqlite3
from typing import List, Optional

app = FastAPI(title="Bolsa de Profesionales API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def init_db():
    conn = sqlite3.connect("bolsa.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS profesionales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            profesion TEXT NOT NULL,
            estudios TEXT,
            graduacion INTEGER NOT NULL,
            labora BOOLEAN NOT NULL,
            empresa TEXT,
            experiencia TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

init_db()

class ProfesionalCreate(BaseModel):
    nombre: str
    profesion: str
    estudios: Optional[str] = ""
    graduacion: int = Field(..., ge=1950, le=2030)
    labora: bool
    empresa: Optional[str] = ""
    experiencia: str

class Profesional(ProfesionalCreate):
    id: int

@app.post("/api/profesionales", response_model=Profesional, status_code=201)
def crear_profesional(prof: ProfesionalCreate):
    conn = sqlite3.connect("bolsa.db")
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO profesionales (nombre, profesion, estudios, graduacion, labora, empresa, experiencia)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (prof.nombre, prof.profesion, prof.estudios, prof.graduacion, prof.labora, prof.empresa, prof.experiencia))
        conn.commit()
        nuevo_id = cursor.lastrowid
        conn.close()
        return {**prof.model_dump(), "id": nuevo_id}
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=500, detail=f"Error en la base de datos: {str(e)}")

@app.get("/api/profesionales", response_model=List[Profesional])
def obtener_profesionales():
    conn = sqlite3.connect("bolsa.db")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM profesionales ORDER BY graduacion DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]
